import { motion } from "framer-motion";
import { Phone, Mail, Clock, MapPin, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";

interface Doctor {
  name: string;
  specialty: string;
  hospital: string;
  phone: string;
  email: string;
  timings: string;
  location: string;
}

const doctors: Record<string, Doctor[]> = {
  heart: [
    { name: "Dr. Rajeev Sharma", specialty: "Interventional Cardiologist", hospital: "AIIMS Delhi", phone: "+91 98765 43210", email: "dr.sharma@aiims.edu", timings: "Mon-Sat 10AM-4PM", location: "New Delhi" },
    { name: "Dr. Priya Mehta", specialty: "Cardiac Surgeon", hospital: "Fortis Hospital", phone: "+91 98765 43211", email: "dr.mehta@fortis.com", timings: "Mon-Fri 9AM-5PM", location: "Mumbai" },
    { name: "Dr. Arun Kumar", specialty: "Cardiologist", hospital: "Apollo Hospital", phone: "+91 98765 43212", email: "dr.kumar@apollo.com", timings: "Mon-Sat 11AM-6PM", location: "Chennai" },
  ],
  lungs: [
    { name: "Dr. Sneha Reddy", specialty: "Pulmonologist", hospital: "Medanta Hospital", phone: "+91 98765 43213", email: "dr.reddy@medanta.org", timings: "Mon-Fri 10AM-4PM", location: "Gurugram" },
    { name: "Dr. Vikram Singh", specialty: "Thoracic Surgeon", hospital: "Max Hospital", phone: "+91 98765 43214", email: "dr.singh@max.com", timings: "Mon-Sat 9AM-3PM", location: "New Delhi" },
    { name: "Dr. Anita Das", specialty: "Chest Medicine Specialist", hospital: "AIIMS Bhopal", phone: "+91 98765 43215", email: "dr.das@aiims.edu", timings: "Mon-Fri 10AM-5PM", location: "Bhopal" },
  ],
};

interface ConsultationSectionProps {
  type: "heart" | "lungs";
}

const ConsultationSection = ({ type }: ConsultationSectionProps) => {
  const selectedDoctors = doctors[type];
  const title = type === "heart" ? "Cardiologists" : "Pulmonologists";

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
      className="mt-8 space-y-6"
    >
      {/* Health Advisory */}
      <div className="bg-secondary/50 rounded-xl p-6 border border-border">
        <h3 className="font-display font-semibold text-foreground text-lg mb-3">⚠️ Health Advisory</h3>
        <ul className="space-y-2 text-sm text-muted-foreground">
          <li>• Please consult a doctor immediately for proper diagnosis</li>
          <li>• This is an AI prediction — not a medical diagnosis</li>
          <li>• Maintain a healthy diet and exercise regularly</li>
          <li>• Get regular health checkups</li>
        </ul>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <a href="tel:108">
          <Button variant="destructive" className="w-full gap-2">
            <Phone className="w-4 h-4" /> Emergency 108
          </Button>
        </a>
        <a href="https://www.practo.com" target="_blank" rel="noopener noreferrer">
          <Button variant="outline" className="w-full gap-2">
            <ExternalLink className="w-4 h-4" /> Online Consultation
          </Button>
        </a>
        <a href="https://www.apollo247.com" target="_blank" rel="noopener noreferrer">
          <Button variant="outline" className="w-full gap-2">
            <ExternalLink className="w-4 h-4" /> Book Appointment
          </Button>
        </a>
      </div>

      {/* Doctors */}
      <div>
        <h3 className="font-display font-semibold text-foreground text-lg mb-4">
          Recommended {title}
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {selectedDoctors.map((doc, i) => (
            <motion.div
              key={doc.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 + i * 0.1 }}
              className="bg-card rounded-xl p-5 border border-border card-shadow"
            >
              <h4 className="font-display font-semibold text-foreground">{doc.name}</h4>
              <p className="text-xs text-primary font-medium mt-1">{doc.specialty}</p>
              <p className="text-xs text-muted-foreground mt-1">{doc.hospital}</p>
              <div className="mt-3 space-y-1.5 text-xs text-muted-foreground">
                <div className="flex items-center gap-2"><Phone className="w-3 h-3" />{doc.phone}</div>
                <div className="flex items-center gap-2"><Mail className="w-3 h-3" />{doc.email}</div>
                <div className="flex items-center gap-2"><Clock className="w-3 h-3" />{doc.timings}</div>
                <div className="flex items-center gap-2"><MapPin className="w-3 h-3" />{doc.location}</div>
              </div>
              <a href={`tel:${doc.phone.replace(/\s/g, "")}`}>
                <Button size="sm" className="w-full mt-4 gap-2">
                  <Phone className="w-3 h-3" /> Call Now
                </Button>
              </a>
            </motion.div>
          ))}
        </div>
      </div>
    </motion.div>
  );
};

export default ConsultationSection;
