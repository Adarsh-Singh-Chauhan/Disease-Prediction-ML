import { Heart } from "lucide-react";
import { Link } from "react-router-dom";

const Footer = () => (
  <footer className="bg-card border-t border-border py-12">
    <div className="container mx-auto px-4">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Heart className="w-5 h-5 text-primary" />
            <span className="font-display font-bold text-foreground">HeartGuard</span>
          </div>
          <p className="text-sm text-muted-foreground">
            AI-powered health prediction system for early disease detection and consultation.
          </p>
        </div>
        <div>
          <h4 className="font-display font-semibold text-foreground mb-3">Quick Links</h4>
          <div className="flex flex-col gap-2">
            {[
              { to: "/heart-predict", label: "Heart Prediction" },
              { to: "/lungs-predict", label: "Lungs Prediction" },
              { to: "/consultation", label: "Consultation" },
              { to: "/about", label: "About" },
            ].map((l) => (
              <Link key={l.to} to={l.to} className="text-sm text-muted-foreground hover:text-primary transition-colors">
                {l.label}
              </Link>
            ))}
          </div>
        </div>
        <div>
          <h4 className="font-display font-semibold text-foreground mb-3">Emergency</h4>
          <p className="text-sm text-muted-foreground mb-1">Emergency Helpline: <strong className="text-primary">108</strong></p>
          <p className="text-sm text-muted-foreground">Heart Attack Helpline: <strong className="text-primary">1800-180-1104</strong></p>
        </div>
      </div>
      <div className="mt-8 pt-6 border-t border-border text-center text-xs text-muted-foreground">
        © 2026 HeartGuard — ML-Powered Health Prediction. For educational purposes only.
      </div>
    </div>
  </footer>
);

export default Footer;
