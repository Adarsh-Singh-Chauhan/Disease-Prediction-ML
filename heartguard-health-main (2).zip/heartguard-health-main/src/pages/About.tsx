import { motion } from "framer-motion";
import { Heart, Database, Brain, BarChart3, ShieldCheck, Users } from "lucide-react";

const sections = [
  { icon: Heart, title: "Heart Disease", desc: "Heart disease is the leading cause of death worldwide. Early detection using clinical data can save millions of lives every year." },
  { icon: Brain, title: "ML Algorithm", desc: "We use Random Forest Classifier — an ensemble learning method that builds multiple decision trees for robust and accurate predictions." },
  { icon: Database, title: "UCI Dataset", desc: "Our model is trained on the Cleveland Heart Disease dataset from UCI Machine Learning Repository, containing 303 patient records with 14 attributes." },
  { icon: BarChart3, title: "Model Accuracy", desc: "Our model achieves 90%+ accuracy with careful feature selection, hyperparameter tuning, and cross-validation." },
  { icon: ShieldCheck, title: "Reliable & Secure", desc: "All data is processed locally. We don't store any personal health information. Your privacy is our top priority." },
  { icon: Users, title: "Who Can Use", desc: "Anyone concerned about heart or lung health can use this tool. It's designed for educational purposes and early risk assessment." },
];

const About = () => (
  <div className="min-h-screen pt-24 pb-16">
    <div className="container mx-auto px-4 max-w-4xl">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
        <h1 className="text-3xl md:text-4xl font-display font-bold text-foreground mb-2">About HeartGuard</h1>
        <p className="text-muted-foreground">Machine Learning powered health prediction system</p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {sections.map((s, i) => (
          <motion.div
            key={s.title}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
            className="bg-card rounded-xl p-6 border border-border card-shadow"
          >
            <s.icon className="w-8 h-8 text-primary mb-3" />
            <h3 className="font-display font-semibold text-foreground mb-2">{s.title}</h3>
            <p className="text-sm text-muted-foreground">{s.desc}</p>
          </motion.div>
        ))}
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        className="mt-12 bg-secondary/50 rounded-xl p-6 border border-border text-center"
      >
        <p className="text-sm text-muted-foreground">
          ⚠️ <strong>Disclaimer:</strong> This tool is for educational and screening purposes only. It does not replace professional medical advice. Always consult a qualified healthcare provider for diagnosis and treatment.
        </p>
      </motion.div>
    </div>
  </div>
);

export default About;
