import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Stethoscope, Search, Phone, Mail, Clock, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface Doctor {
  name: string;
  specialty: string;
  hospital: string;
  phone: string;
  email: string;
  timings: string;
  location: string;
  diseases: string[];
}

const allDoctors: Doctor[] = [
  { name: "Dr. Rajeev Sharma", specialty: "Cardiologist", hospital: "AIIMS Delhi", phone: "+91 98765 43210", email: "dr.sharma@aiims.edu", timings: "Mon-Sat 10AM-4PM", location: "New Delhi", diseases: ["heart", "bp", "blood pressure", "chest pain", "cardiac", "cholesterol"] },
  { name: "Dr. Priya Mehta", specialty: "Cardiac Surgeon", hospital: "Fortis Hospital", phone: "+91 98765 43211", email: "dr.mehta@fortis.com", timings: "Mon-Fri 9AM-5PM", location: "Mumbai", diseases: ["heart", "cardiac", "surgery", "bypass"] },
  { name: "Dr. Sneha Reddy", specialty: "Pulmonologist", hospital: "Medanta Hospital", phone: "+91 98765 43213", email: "dr.reddy@medanta.org", timings: "Mon-Fri 10AM-4PM", location: "Gurugram", diseases: ["lungs", "asthma", "breathing", "cough", "tb", "pneumonia", "copd"] },
  { name: "Dr. Vikram Singh", specialty: "Thoracic Surgeon", hospital: "Max Hospital", phone: "+91 98765 43214", email: "dr.singh@max.com", timings: "Mon-Sat 9AM-3PM", location: "New Delhi", diseases: ["lungs", "lung cancer", "thoracic", "chest"] },
  { name: "Dr. Anjali Gupta", specialty: "Endocrinologist", hospital: "Medanta Hospital", phone: "+91 98765 43216", email: "dr.gupta@medanta.org", timings: "Mon-Fri 10AM-5PM", location: "Gurugram", diseases: ["diabetes", "thyroid", "sugar", "hormones", "pcos"] },
  { name: "Dr. Rahul Verma", specialty: "Neurologist", hospital: "Fortis Hospital", phone: "+91 98765 43217", email: "dr.verma@fortis.com", timings: "Mon-Sat 11AM-6PM", location: "Delhi", diseases: ["brain", "headache", "migraine", "stroke", "paralysis", "epilepsy", "nerve"] },
  { name: "Dr. Meera Joshi", specialty: "Nephrologist", hospital: "Apollo Hospital", phone: "+91 98765 43218", email: "dr.joshi@apollo.com", timings: "Mon-Fri 9AM-4PM", location: "Chennai", diseases: ["kidney", "renal", "dialysis", "urine", "stone"] },
  { name: "Dr. Karan Malhotra", specialty: "Dermatologist", hospital: "Max Hospital", phone: "+91 98765 43219", email: "dr.malhotra@max.com", timings: "Mon-Sat 10AM-5PM", location: "Mumbai", diseases: ["skin", "acne", "rash", "allergy", "eczema", "psoriasis", "hair"] },
  { name: "Dr. Sunita Patel", specialty: "Gastroenterologist", hospital: "AIIMS Delhi", phone: "+91 98765 43220", email: "dr.patel@aiims.edu", timings: "Mon-Fri 10AM-4PM", location: "New Delhi", diseases: ["stomach", "liver", "digestion", "acidity", "ulcer", "gastric", "jaundice"] },
  { name: "Dr. Amit Kapoor", specialty: "Orthopedic Surgeon", hospital: "Fortis Hospital", phone: "+91 98765 43221", email: "dr.kapoor@fortis.com", timings: "Mon-Sat 9AM-5PM", location: "Bangalore", diseases: ["bone", "joint", "fracture", "knee", "spine", "back pain", "arthritis"] },
  { name: "Dr. Ritu Saxena", specialty: "Oncologist", hospital: "Tata Memorial Hospital", phone: "+91 98765 43222", email: "dr.saxena@tata.org", timings: "Mon-Fri 10AM-4PM", location: "Mumbai", diseases: ["cancer", "tumor", "chemotherapy", "oncology", "lump"] },
  { name: "Dr. Deepak Nair", specialty: "General Physician", hospital: "Apollo Hospital", phone: "+91 98765 43223", email: "dr.nair@apollo.com", timings: "Mon-Sat 8AM-8PM", location: "Delhi", diseases: ["fever", "cold", "flu", "infection", "general", "weakness", "covid", "viral"] },
];

const Consultation = () => {
  const [query, setQuery] = useState("");
  const [searched, setSearched] = useState(false);
  const [matchedDoctors, setMatchedDoctors] = useState<Doctor[]>([]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const q = query.toLowerCase().trim();
    if (!q) return;

    const matched = allDoctors.filter((d) =>
      d.diseases.some((dis) => q.includes(dis)) ||
      d.specialty.toLowerCase().includes(q)
    );

    // If no specific match, show general physicians
    setMatchedDoctors(matched.length > 0 ? matched : allDoctors.filter((d) => d.specialty === "General Physician"));
    setSearched(true);
  };

  return (
    <div className="min-h-screen pt-24 pb-16">
      <div className="container mx-auto px-4 max-w-4xl">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-10">
          <Stethoscope className="w-12 h-12 text-primary mx-auto mb-4" />
          <h1 className="text-3xl md:text-4xl font-display font-bold text-foreground mb-2">Instant Consultation</h1>
          <p className="text-muted-foreground">Apni bimari ya problem type karo aur turant specialist doctors ki details paao</p>
        </motion.div>

        <motion.form
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          onSubmit={handleSearch}
          className="bg-card rounded-2xl p-6 md:p-8 border border-border card-shadow"
        >
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Examples: heart disease, diabetes, kidney problem, skin allergy, headache, cancer, breathing problem, bone fracture, stomach pain, fever...
            </p>
            <div className="flex gap-3">
              <Input
                type="text"
                placeholder="Type your disease or problem here..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="flex-1 text-lg h-12"
                required
              />
              <Button type="submit" size="lg" className="gap-2 h-12">
                <Search className="w-4 h-4" /> Search
              </Button>
            </div>
          </div>

          {/* Quick tags */}
          <div className="flex flex-wrap gap-2 mt-4">
            {["Heart Disease", "Diabetes", "Lungs Problem", "Kidney Issue", "Skin Allergy", "Headache", "Fever", "Cancer", "Back Pain", "Stomach Pain"].map((tag) => (
              <button
                key={tag}
                type="button"
                onClick={() => { setQuery(tag); }}
                className="px-3 py-1.5 text-xs font-medium rounded-full bg-secondary text-secondary-foreground hover:bg-primary hover:text-primary-foreground transition-colors"
              >
                {tag}
              </button>
            ))}
          </div>
        </motion.form>

        <AnimatePresence>
          {searched && (
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="mt-8"
            >
              <h2 className="text-xl font-display font-semibold text-foreground mb-4">
                🏥 Found {matchedDoctors.length} Specialist{matchedDoctors.length > 1 ? "s" : ""} for "{query}"
              </h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {matchedDoctors.map((doc, i) => (
                  <motion.div
                    key={doc.name + doc.hospital}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.08 }}
                    className="bg-card rounded-xl p-5 border border-border card-shadow"
                  >
                    <h3 className="font-display font-semibold text-foreground">{doc.name}</h3>
                    <p className="text-xs text-primary font-medium mt-1">{doc.specialty}</p>
                    <p className="text-xs text-muted-foreground">{doc.hospital}</p>
                    <div className="mt-3 space-y-1.5 text-xs text-muted-foreground">
                      <div className="flex items-center gap-2"><Phone className="w-3 h-3" />{doc.phone}</div>
                      <div className="flex items-center gap-2"><Mail className="w-3 h-3" />{doc.email}</div>
                      <div className="flex items-center gap-2"><Clock className="w-3 h-3" />{doc.timings}</div>
                      <div className="flex items-center gap-2"><MapPin className="w-3 h-3" />{doc.location}</div>
                    </div>
                    <div className="flex gap-2 mt-4">
                      <a href={`tel:${doc.phone.replace(/\s/g, "")}`} className="flex-1">
                        <Button size="sm" className="w-full gap-1"><Phone className="w-3 h-3" /> Call</Button>
                      </a>
                      <a href={`mailto:${doc.email}`} className="flex-1">
                        <Button size="sm" variant="outline" className="w-full gap-1"><Mail className="w-3 h-3" /> Email</Button>
                      </a>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default Consultation;
