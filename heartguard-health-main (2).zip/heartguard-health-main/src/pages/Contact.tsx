import { useState } from "react";
import { motion } from "framer-motion";
import { Mail, Github, Linkedin, Send, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

const Contact = () => {
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
    setTimeout(() => setSent(false), 3000);
  };

  return (
    <div className="min-h-screen pt-24 pb-16">
      <div className="container mx-auto px-4 max-w-2xl">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-10">
          <Mail className="w-12 h-12 text-primary mx-auto mb-4" />
          <h1 className="text-3xl md:text-4xl font-display font-bold text-foreground mb-2">Contact Us</h1>
          <p className="text-muted-foreground">Have questions or feedback? We'd love to hear from you.</p>
        </motion.div>

        <motion.form
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          onSubmit={handleSubmit}
          className="bg-card rounded-2xl p-6 md:p-8 border border-border card-shadow space-y-5"
        >
          <div className="space-y-1.5">
            <Label>Name</Label>
            <Input placeholder="Your name" required />
          </div>
          <div className="space-y-1.5">
            <Label>Email</Label>
            <Input type="email" placeholder="you@email.com" required />
          </div>
          <div className="space-y-1.5">
            <Label>Message</Label>
            <Textarea placeholder="Your message..." rows={5} required />
          </div>
          <Button type="submit" className="w-full gap-2" disabled={sent}>
            {sent ? <><CheckCircle className="w-4 h-4" /> Sent!</> : <><Send className="w-4 h-4" /> Send Message</>}
          </Button>
        </motion.form>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mt-8 flex justify-center gap-4"
        >
          <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="p-3 bg-card border border-border rounded-xl text-muted-foreground hover:text-foreground hover:card-shadow-hover transition-all">
            <Github className="w-5 h-5" />
          </a>
          <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="p-3 bg-card border border-border rounded-xl text-muted-foreground hover:text-foreground hover:card-shadow-hover transition-all">
            <Linkedin className="w-5 h-5" />
          </a>
          <a href="mailto:heartguard@example.com" className="p-3 bg-card border border-border rounded-xl text-muted-foreground hover:text-foreground hover:card-shadow-hover transition-all">
            <Mail className="w-5 h-5" />
          </a>
        </motion.div>
      </div>
    </div>
  );
};

export default Contact;
