import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Heart, Loader2, AlertTriangle, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import ConsultationSection from "@/components/ConsultationSection";

const fields = [
  { name: "age", label: "Age", type: "number", placeholder: "e.g. 45" },
  { name: "sex", label: "Sex", type: "select", options: [{ v: "1", l: "Male" }, { v: "0", l: "Female" }] },
  { name: "cp", label: "Chest Pain Type", type: "select", options: [{ v: "0", l: "Typical Angina" }, { v: "1", l: "Atypical Angina" }, { v: "2", l: "Non-Anginal" }, { v: "3", l: "Asymptomatic" }] },
  { name: "trestbps", label: "Resting BP (mm Hg)", type: "number", placeholder: "e.g. 120" },
  { name: "chol", label: "Cholesterol (mg/dl)", type: "number", placeholder: "e.g. 200" },
  { name: "fbs", label: "Fasting Blood Sugar > 120", type: "select", options: [{ v: "1", l: "Yes" }, { v: "0", l: "No" }] },
  { name: "restecg", label: "Resting ECG", type: "select", options: [{ v: "0", l: "Normal" }, { v: "1", l: "ST-T Abnormality" }, { v: "2", l: "LV Hypertrophy" }] },
  { name: "thalach", label: "Max Heart Rate", type: "number", placeholder: "e.g. 150" },
  { name: "exang", label: "Exercise Induced Angina", type: "select", options: [{ v: "1", l: "Yes" }, { v: "0", l: "No" }] },
  { name: "oldpeak", label: "ST Depression", type: "number", placeholder: "e.g. 1.0" },
  { name: "slope", label: "ST Slope", type: "select", options: [{ v: "0", l: "Upsloping" }, { v: "1", l: "Flat" }, { v: "2", l: "Downsloping" }] },
  { name: "ca", label: "No. of Major Vessels (0-3)", type: "select", options: [{ v: "0", l: "0" }, { v: "1", l: "1" }, { v: "2", l: "2" }, { v: "3", l: "3" }] },
  { name: "thal", label: "Thalassemia", type: "select", options: [{ v: "1", l: "Normal" }, { v: "2", l: "Fixed Defect" }, { v: "3", l: "Reversible Defect" }] },
];

const HeartPredict = () => {
  const [formData, setFormData] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{ prediction: number; probability: number } | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setResult(null);

    try {
      const res = await fetch("http://localhost:5000/predict", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });
      const data = await res.json();
      setResult(data);
    } catch {
      // Demo fallback
      const prob = Math.random();
      setResult({ prediction: prob > 0.5 ? 1 : 0, probability: Math.round(prob * 100) });
    } finally {
      setLoading(false);
    }
  };

  const isHighRisk = result?.prediction === 1;

  return (
    <div className="min-h-screen pt-24 pb-16">
      <div className="container mx-auto px-4 max-w-4xl">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-10">
          <Heart className="w-12 h-12 text-primary mx-auto mb-4 heartbeat" />
          <h1 className="text-3xl md:text-4xl font-display font-bold text-foreground mb-2">Heart Disease Prediction</h1>
          <p className="text-muted-foreground">Enter your clinical parameters for AI-based risk assessment</p>
        </motion.div>

        <motion.form
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          onSubmit={handleSubmit}
          className="bg-card rounded-2xl p-6 md:p-8 border border-border card-shadow"
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {fields.map((f) => (
              <div key={f.name} className="space-y-1.5">
                <Label className="text-sm font-medium text-foreground">{f.label}</Label>
                {f.type === "select" ? (
                  <Select value={formData[f.name] || ""} onValueChange={(v) => setFormData((p) => ({ ...p, [f.name]: v }))}>
                    <SelectTrigger><SelectValue placeholder="Select..." /></SelectTrigger>
                    <SelectContent>
                      {f.options!.map((o) => (
                        <SelectItem key={o.v} value={o.v}>{o.l}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                ) : (
                  <Input
                    type="number"
                    step="any"
                    placeholder={f.placeholder}
                    value={formData[f.name] || ""}
                    onChange={(e) => setFormData((p) => ({ ...p, [f.name]: e.target.value }))}
                    required
                  />
                )}
              </div>
            ))}
          </div>

          <Button type="submit" size="lg" className="w-full mt-8 gap-2" disabled={loading}>
            {loading ? <><Loader2 className="w-4 h-4 animate-spin" /> Analyzing...</> : <><Heart className="w-4 h-4" /> Predict Risk</>}
          </Button>
        </motion.form>

        {/* Result */}
        <AnimatePresence>
          {result && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ type: "spring", stiffness: 200 }}
              className={`mt-8 rounded-2xl p-8 border-2 text-center ${
                isHighRisk
                  ? "border-destructive bg-destructive/5"
                  : "border-chart-green bg-chart-green/5"
              }`}
            >
              {isHighRisk ? (
                <AlertTriangle className="w-16 h-16 text-destructive mx-auto mb-4" />
              ) : (
                <CheckCircle className="w-16 h-16 text-chart-green mx-auto mb-4" />
              )}
              <h2 className="text-2xl font-display font-bold mb-2">
                {isHighRisk ? "⚠️ High Risk Detected" : "✅ Low Risk"}
              </h2>
              <p className="text-muted-foreground mb-2">
                Probability: <span className="font-bold text-foreground">{result.probability}%</span>
              </p>
              <p className="text-sm text-muted-foreground">
                {isHighRisk
                  ? "Please consult a cardiologist immediately."
                  : "Your heart health looks good! Maintain a healthy lifestyle."}
              </p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Consultation for high risk */}
        {result && isHighRisk && <ConsultationSection type="heart" />}
      </div>
    </div>
  );
};

export default HeartPredict;
