import { motion } from "framer-motion";
import { Heart, Activity, Stethoscope, ShieldCheck, ArrowRight, Wind } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

const features = [
  { icon: Heart, title: "Heart Disease Prediction", desc: "13 clinical parameters analyzed by Random Forest ML model", link: "/heart-predict", color: "text-primary" },
  { icon: Wind, title: "Lungs Disease Prediction", desc: "Assess lung cancer risk using lifestyle and symptom data", link: "/lungs-predict", color: "text-accent" },
  { icon: Stethoscope, title: "Instant Consultation", desc: "Enter your condition and get matched with specialist doctors", link: "/consultation", color: "text-chart-green" },
  { icon: ShieldCheck, title: "Trusted & Accurate", desc: "Based on UCI dataset with 90%+ accuracy across models", color: "text-chart-amber" },
];

const stats = [
  { value: "90%+", label: "Accuracy" },
  { value: "13+", label: "Parameters" },
  { value: "1000+", label: "Dataset Records" },
  { value: "24/7", label: "Available" },
];

const Index = () => {
  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="relative hero-gradient min-h-screen flex items-center overflow-hidden">
        {/* Floating blobs */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-20 left-10 w-72 h-72 bg-primary/5 rounded-full blur-3xl animate-float" />
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-accent/5 rounded-full blur-3xl animate-float-delayed" />
        </div>

        <div className="container mx-auto px-4 pt-24 pb-16 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
              className="mb-6"
            >
              <Heart className="w-16 h-16 text-primary mx-auto heartbeat" />
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-4xl md:text-6xl font-display font-bold text-foreground leading-tight mb-6"
            >
              AI-Powered{" "}
              <span className="text-gradient">Health Prediction</span>{" "}
              System
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="text-lg text-muted-foreground mb-8 max-w-xl mx-auto"
            >
              Predict heart and lung diseases early using machine learning. Get instant risk assessment and connect with specialist doctors.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="flex flex-col sm:flex-row gap-4 justify-center"
            >
              <Link to="/heart-predict">
                <Button size="lg" className="gap-2 w-full sm:w-auto">
                  <Heart className="w-4 h-4" /> Heart Prediction <ArrowRight className="w-4 h-4" />
                </Button>
              </Link>
              <Link to="/lungs-predict">
                <Button size="lg" variant="outline" className="gap-2 w-full sm:w-auto">
                  <Wind className="w-4 h-4" /> Lungs Prediction
                </Button>
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-12 bg-card border-y border-border">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((s, i) => (
              <motion.div
                key={s.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="text-center"
              >
                <div className="text-3xl font-display font-bold text-primary">{s.value}</div>
                <div className="text-sm text-muted-foreground mt-1">{s.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl font-display font-bold text-foreground text-center mb-12"
          >
            What We Offer
          </motion.h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((f, i) => (
              <motion.div
                key={f.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                whileHover={{ y: -4 }}
                className="bg-card rounded-xl p-6 border border-border card-shadow hover:card-shadow-hover transition-shadow"
              >
                <f.icon className={`w-10 h-10 ${f.color} mb-4`} />
                <h3 className="font-display font-semibold text-foreground mb-2">{f.title}</h3>
                <p className="text-sm text-muted-foreground mb-4">{f.desc}</p>
                {f.link && (
                  <Link to={f.link} className="text-sm text-primary font-medium hover:underline inline-flex items-center gap-1">
                    Try Now <ArrowRight className="w-3 h-3" />
                  </Link>
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 hero-gradient">
        <div className="container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
          >
            <Activity className="w-12 h-12 text-primary mx-auto mb-4" />
            <h2 className="text-3xl font-display font-bold text-foreground mb-4">
              Check Your Health Now
            </h2>
            <p className="text-muted-foreground mb-8 max-w-md mx-auto">
              Early detection saves lives. Get your risk assessment in seconds.
            </p>
            <Link to="/consultation">
              <Button size="lg" className="gap-2">
                <Stethoscope className="w-4 h-4" /> Get Consultation
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Index;
