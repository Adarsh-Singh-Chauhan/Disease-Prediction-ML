import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Wind, Loader2, AlertTriangle, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import ConsultationSection from "@/components/ConsultationSection";

const yesNo = [{ v: "2", l: "Yes" }, { v: "1", l: "No" }];

const fields = [
  { name: "age", label: "Age", type: "number", placeholder: "e.g. 55" },
  { name: "gender", label: "Gender", type: "select", options: [{ v: "M", l: "Male" }, { v: "F", l: "Female" }] },
  { name: "smoking", label: "Smoking", type: "select", options: yesNo },
  { name: "yellow_fingers", label: "Yellow Fingers", type: "select", options: yesNo },
  { name: "anxiety", label: "Anxiety", type: "select", options: yesNo },
  { name: "peer_pressure", label: "Peer Pressure", type: "select", options: yesNo },
  { name: "chronic_disease", label: "Chronic Disease", type: "select", options: yesNo },
  { name: "fatigue", label: "Fatigue", type: "select", options: yesNo },
  { name: "allergy", label: "Allergy", type: "select", options: yesNo },
  { name: "wheezing", label: "Wheezing", type: "select", options: yesNo },
  { name: "alcohol", label: "Alcohol Consuming", type: "select", options: yesNo },
  { name: "coughing", label: "Coughing", type: "select", options: yesNo },
  { name: "shortness_of_breath", label: "Shortness of Breath", type: "select", options: yesNo },
  { name: "swallowing_difficulty", label: "Swallowing Difficulty", type: "select", options: yesNo },
  { name: "chest_pain", label: "Chest Pain", type: "select", options: yesNo },
];

const LungsPredict = () => {
  const [formData, setFormData] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{ prediction: number; probability: number } | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setResult(null);

    try {
      const res = await fetch("http://localhost:5000/predict-lungs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });
      const data = await res.json();
      setResult(data);
    } catch {
      const prob = Math.random();
      setResult({ prediction: prob > 0.5 ? 1 : 0, probability: Math.round(prob * 100) });
    } finally {
      setLoading(false);
    }
  };

  const isHighRisk = result?.prediction === 1;

  return (
    <div className="min-h-screen pt-24 pb-16">
      <div className="container mx-auto px-4 max-w-4xl">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-10">
          <Wind className="w-12 h-12 text-accent mx-auto mb-4" />
          <h1 className="text-3xl md:text-4xl font-display font-bold text-foreground mb-2">Lungs Disease Prediction</h1>
          <p className="text-muted-foreground">Assess your lung cancer risk using lifestyle and symptom data</p>
        </motion.div>

        <motion.form
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          onSubmit={handleSubmit}
          className="bg-card rounded-2xl p-6 md:p-8 border border-border card-shadow"
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {fields.map((f) => (
              <div key={f.name} className="space-y-1.5">
                <Label className="text-sm font-medium text-foreground">{f.label}</Label>
                {f.type === "select" ? (
                  <Select value={formData[f.name] || ""} onValueChange={(v) => setFormData((p) => ({ ...p, [f.name]: v }))}>
                    <SelectTrigger><SelectValue placeholder="Select..." /></SelectTrigger>
                    <SelectContent>
                      {f.options!.map((o) => (
                        <SelectItem key={o.v} value={o.v}>{o.l}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                ) : (
                  <Input
                    type="number"
                    placeholder={f.placeholder}
                    value={formData[f.name] || ""}
                    onChange={(e) => setFormData((p) => ({ ...p, [f.name]: e.target.value }))}
                    required
                  />
                )}
              </div>
            ))}
          </div>

          <Button type="submit" size="lg" className="w-full mt-8 gap-2" disabled={loading}>
            {loading ? <><Loader2 className="w-4 h-4 animate-spin" /> Analyzing...</> : <><Wind className="w-4 h-4" /> Predict Risk</>}
          </Button>
        </motion.form>

        <AnimatePresence>
          {result && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ type: "spring", stiffness: 200 }}
              className={`mt-8 rounded-2xl p-8 border-2 text-center ${
                isHighRisk ? "border-destructive bg-destructive/5" : "border-chart-green bg-chart-green/5"
              }`}
            >
              {isHighRisk ? <AlertTriangle className="w-16 h-16 text-destructive mx-auto mb-4" /> : <CheckCircle className="w-16 h-16 text-chart-green mx-auto mb-4" />}
              <h2 className="text-2xl font-display font-bold mb-2">{isHighRisk ? "⚠️ High Risk Detected" : "✅ Low Risk"}</h2>
              <p className="text-muted-foreground mb-2">Probability: <span className="font-bold text-foreground">{result.probability}%</span></p>
              <p className="text-sm text-muted-foreground">{isHighRisk ? "Please consult a pulmonologist immediately." : "Your lungs appear healthy! Avoid smoking and polluted environments."}</p>
            </motion.div>
          )}
        </AnimatePresence>

        {result && isHighRisk && <ConsultationSection type="lungs" />}
      </div>
    </div>
  );
};

export default LungsPredict;
